package com.example.bookstore.service;

import com.example.bookstore.entity.Author;
import com.example.bookstore.repository.AuthorRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AuthorService {

    private final AuthorRepository authorRepository;

    public AuthorService(AuthorRepository authorRepository) {
        this.authorRepository = authorRepository;
    }

    // ✅ Create Author
    public Author createAuthor(Author author) {
        return authorRepository.save(author);
    }

    // ✅ Get all Authors
    public List<Author> getAllAuthors() {
        return authorRepository.findAll();
    }

    // ✅ Get Author by ID
    public Optional<Author> getAuthorById(Long id) {
        return authorRepository.findById(id);
    }

    // ✅ Update Author
    public Optional<Author> updateAuthor(Long id, Author authorDetails) {
        return authorRepository.findById(id).map(existing -> {
            existing.setName(authorDetails.getName());
            existing.setBio(authorDetails.getBio());
            return authorRepository.save(existing);
        });
    }

    // ✅ Delete Author
    public boolean deleteAuthor(Long id) {
        if (authorRepository.existsById(id)) {
            authorRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
