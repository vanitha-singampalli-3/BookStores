package com.example.bookstore.service;

import com.example.bookstore.dto.BookDTO;
import com.example.bookstore.entity.Author;
import com.example.bookstore.entity.Book;
import com.example.bookstore.repository.AuthorRepository;
import com.example.bookstore.repository.BookRepository;
import com.example.bookstore.spec.BookSpecification;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class BookService {
    @Autowired
    private BookRepository bookRepo;

    @Autowired
    private AuthorRepository authorRepo;

    // Create

    public Book createBook(Book book, Long authorId) {
        Author author = authorRepo.findById(authorId)
                .orElseThrow(() -> new RuntimeException("Author not found: " + authorId));

        book.setAuthor(author);
        return bookRepo.save(book);
    }


    // Update
    public Book updateBook(Long id, BookDTO dto) {
        Book book = bookRepo.findById(id).orElseThrow(() -> new RuntimeException("Book not found: " + id));
        if (dto.getTitle() != null) book.setTitle(dto.getTitle());
        if (dto.getIsbn() != null) book.setIsbn(dto.getIsbn());
        if (dto.getPages() != null) book.setPages(dto.getPages());
        if (dto.getPublishedDate() != null) book.setPublishedDate(dto.getPublishedDate());
        if (dto.getAuthorId() != null) {
            Author author = authorRepo.findById(dto.getAuthorId())
                    .orElseThrow(() -> new RuntimeException("Author not found: " + dto.getAuthorId()));
            book.setAuthor(author);
        }
        return bookRepo.save(book);
    }

    // Read
    public Optional<Book> getById(Long id) {
        return bookRepo.findById(id);
    }

    // Delete
    public void delete(Long id) {
        bookRepo.deleteById(id);
    }

    public Page<Book> searchBooks(String title, String isbn, Integer minPages,
            LocalDate publishedAfter, String authorName, Pageable pageable) {
Specification<Book> spec = Specification.where(BookSpecification.titleContains(title))
.and(BookSpecification.isbnEquals(isbn))
.and(BookSpecification.pagesGreaterOrEqual(minPages))
.and(BookSpecification.publishedAfter(publishedAfter))
.and(BookSpecification.authorNameContains(authorName));

return bookRepo.findAll(spec, pageable);
}
    public List<Book> getAllBooks() {
        return bookRepo.findAll();
    }

    

}
