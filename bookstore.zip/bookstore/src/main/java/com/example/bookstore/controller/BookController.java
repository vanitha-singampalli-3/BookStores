package com.example.bookstore.controller;

import com.example.bookstore.dto.BookDTO;
import com.example.bookstore.entity.Book;
import com.example.bookstore.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.*;
import org.springframework.data.jpa.domain.Specification;


@RestController
@RequestMapping("/api/books")
public class BookController {
    @Autowired
    private BookService bookService;

    @PostMapping
    public ResponseEntity<Book> create(@RequestBody BookDTO dto) {
        Book book = new Book();
        book.setTitle(dto.getTitle());
        book.setIsbn(dto.getIsbn());
        book.setPages(dto.getPages());
        book.setPublishedDate(dto.getPublishedDate());

        Book saved = bookService.createBook(book, dto.getAuthorId());
        return ResponseEntity.ok(saved);
    }


    @GetMapping("/{id}")
    public ResponseEntity<Book> get(@PathVariable Long id) {
        return bookService.getById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Book> update(@PathVariable Long id, @RequestBody BookDTO dto) {
        Book updated = bookService.updateBook(id, dto);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        bookService.delete(id);
        return ResponseEntity.noContent().build();
    }
    
 // Controller
    @GetMapping("/search")
    public ResponseEntity<Page<Book>> search(
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String isbn,
            @RequestParam(required = false) Integer minPages,
            @RequestParam(required = false) String authorName,
            @RequestParam(required = false)
              @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
              LocalDate publishedAfter,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id,asc") String sort
    ) {
        String[] parts = sort.split(",");
        String prop = parts[0];
        Sort.Direction dir = (parts.length > 1 && parts[1].equalsIgnoreCase("desc"))
                ? Sort.Direction.DESC : Sort.Direction.ASC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(dir, prop));

        Page<Book> result = bookService.searchBooks(title, isbn, minPages,
                publishedAfter, authorName, pageable);
        return ResponseEntity.ok(result);
    }



    @GetMapping
    public ResponseEntity<List<BookDTO>> getAllBooks() {
        List<BookDTO> list = bookService.getAllBooks()
            .stream()
            .map(book -> {
                BookDTO dto = new BookDTO();
                dto.setId(book.getId());
                dto.setTitle(book.getTitle());
                dto.setIsbn(book.getIsbn());
                dto.setPages(book.getPages());
                dto.setPublishedDate(book.getPublishedDate());
                dto.setAuthorId(book.getAuthor().getId());
                dto.setAuthorName(book.getAuthor().getName());
                return dto;
            })
            .toList();
        return ResponseEntity.ok(list);
    }

}
