package com.example.bookstore.dto;

import java.time.LocalDate;

public class BookDTO {
    private Long id;
    private String title;
    private String isbn;
    private Integer pages;
    private LocalDate publishedDate;
    private Long authorId;
    private String authorName; // optional for responses
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public Integer getPages() {
		return pages;
	}
	public void setPages(Integer pages) {
		this.pages = pages;
	}
	public LocalDate getPublishedDate() {
		return publishedDate;
	}
	public void setPublishedDate(LocalDate publishedDate) {
		this.publishedDate = publishedDate;
	}
	public Long getAuthorId() {
		return authorId;
	}
	public void setAuthorId(Long authorId) {
		this.authorId = authorId;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	@Override
	public String toString() {
		return "BookDTO [id=" + id + ", title=" + title + ", isbn=" + isbn + ", pages=" + pages + ", publishedDate="
				+ publishedDate + ", authorId=" + authorId + ", authorName=" + authorName + "]";
	}

    // getters & setters, constructors
}
