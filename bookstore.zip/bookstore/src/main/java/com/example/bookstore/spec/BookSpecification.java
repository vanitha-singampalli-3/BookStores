package com.example.bookstore.spec;

import com.example.bookstore.entity.Book;
import org.springframework.data.jpa.domain.Specification;

import java.time.LocalDate;

public class BookSpecification {

    public static Specification<Book> titleContains(String title) {
        return (root, query, cb) ->
            title == null ? null :
            cb.like(cb.lower(root.get("title")), "%" + title.toLowerCase() + "%");
    }

    public static Specification<Book> isbnEquals(String isbn) {
        return (root, query, cb) ->
            isbn == null ? null :
            cb.equal(root.get("isbn"), isbn);
    }

    public static Specification<Book> pagesGreaterOrEqual(Integer minPages) {
        return (root, query, cb) ->
            minPages == null ? null :
            cb.greaterThanOrEqualTo(root.get("pages"), minPages);
    }

    public static Specification<Book> publishedAfter(LocalDate publishedAfter) {
        return (root, query, cb) ->
            publishedAfter == null ? null :
            cb.greaterThan(root.get("publishedDate"), publishedAfter);
    }

    public static Specification<Book> authorNameContains(String authorName) {
        return (root, query, cb) ->
            authorName == null ? null :
            cb.like(cb.lower(root.join("author").get("name")), "%" + authorName.toLowerCase() + "%");
    }
}
