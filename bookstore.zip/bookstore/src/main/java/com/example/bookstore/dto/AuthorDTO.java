package com.example.bookstore.dto;

public class AuthorDTO {
    private Long id;
    private String name;
    private String bio;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBio() {
		return bio;
	}
	public void setBio(String bio) {
		this.bio = bio;
	}
	@Override
	public String toString() {
		return "AuthorDTO [id=" + id + ", name=" + name + ", bio=" + bio + "]";
	}
	
    // getters & setters, constructors
    
}
